<?php
// Penduduk.php
class Model_home extends CI_Model {
	public function __construct()
	{
		$this->load->database();
	}
 
	
 
}